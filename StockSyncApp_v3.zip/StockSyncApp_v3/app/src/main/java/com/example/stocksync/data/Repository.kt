package com.example.stocksync.data

import android.content.Context
import androidx.room.Room
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class Repository private constructor(ctx: Context){
    private val db = Room.databaseBuilder(ctx, AppDatabase::class.java, AppDatabase.NAME).build()
    private val gson = Gson()

    fun itemsWithRelations(): Flow<List<ItemWithRelations>> = db.itemDao().allWithRelations()
    fun prices(itemId: String): Flow<List<PriceEntity>> = db.priceDao().forItem(itemId)
    fun movements(itemId: String): Flow<List<StockMovementEntity>> = db.stockDao().forItem(itemId)
    fun allUnits(): Flow<List<UnitEntity>> = db.unitDao().all()

    suspend fun addOrUpdateItem(item: ItemEntity){
        val up = item.copy(lastUpdated = System.currentTimeMillis())
        db.itemDao().upsert(up); enqueueChange("items", "upsert", up)
    }
    suspend fun softDeleteItem(id: String){
        val ts = System.currentTimeMillis()
        db.itemDao().softDelete(id, ts); enqueueChange("items", "delete", mapOf("id" to id, "lastUpdated" to ts))
    }
    suspend fun setPrice(p: PriceEntity){
        val up = p.copy(lastUpdated = System.currentTimeMillis())
        db.priceDao().upsert(up); enqueueChange("prices", "upsert", up)
    }
    suspend fun addMovement(m: StockMovementEntity){
        db.stockDao().add(m); enqueueChange("stock_movements", "upsert", m)
    }

    suspend fun seedDefaultUnits(){
        withContext(Dispatchers.IO){
            db.unitDao().upsert(
                UnitEntity(id="pcs", name="pcs", toBaseMultiplier = 1.0),
                UnitEntity(id="bks", name="bks", toBaseMultiplier = 12.0),
                UnitEntity(id="pak", name="pak", toBaseMultiplier = 24.0)
            )
        }
    }

    suspend fun pending(): List<PendingChangeEntity> = db.pendingDao().all()
    suspend fun ackPending(id: String) = db.pendingDao().delete(id)

    private suspend fun enqueueChange(table: String, op: String, payload: Any){
        val json = gson.toJson(payload)
        db.pendingDao().upsert(PendingChangeEntity(tableName = table, op = op, payloadJson = json))
    }

    companion object {
        @Volatile private var INSTANCE: Repository? = null
        fun get(ctx: Context): Repository = INSTANCE ?: synchronized(this){
            INSTANCE ?: Repository(ctx.applicationContext).also { INSTANCE = it }
        }
    }
}