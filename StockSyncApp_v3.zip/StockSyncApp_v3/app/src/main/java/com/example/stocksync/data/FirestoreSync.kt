package com.example.stocksync.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.gson.Gson
import kotlinx.coroutines.tasks.await

class FirestoreSync {
    private val fs = FirebaseFirestore.getInstance()
    private val gson = Gson()

    private fun userRoot(): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: "public"
        return "users/$uid"
    }

    suspend fun pushAll(changes: List<PendingChangeEntity>) {
        val root = userRoot()
        for (c in changes) {
            val obj = gson.fromJson(c.payloadJson, Map::class.java)
            val id = (obj["id"] ?: obj["itemId"] ?: obj["unitId"]).toString()
            val collection = when (c.tableName) {
                "items" -> "items"
                "prices" -> "prices"
                "stock_movements" -> "stock_movements"
                "units" -> "units"
                else -> c.tableName
            }
            fs.collection("$root/$collection").document(id).set(obj, SetOptions.merge()).await()
        }
    }

    suspend fun pullAll(repo: Repository){
        val root = userRoot()

        // Items
        fs.collection("$root/items").get().await().documents.mapNotNull { it.data }.forEach {
            val e = ItemEntity(
                id = it["id"] as String,
                name = it["name"] as String,
                sku = it["sku"] as String,
                baseUnitId = (it["baseUnitId"] as? String) ?: "pcs",
                lastUpdated = (it["lastUpdated"] as Number?)?.toLong() ?: 0L,
                deleted = it["deleted"] as Boolean? ?: false
            )
            repo.addOrUpdateItem(e)
        }

        // Prices
        fs.collection("$root/prices").get().await().documents.mapNotNull { it.data }.forEach {
            val e = PriceEntity(
                id = it["id"] as String,
                itemId = it["itemId"] as String,
                unitId = it["unitId"] as String,
                price = (it["price"] as Number).toLong(),
                lastUpdated = (it["lastUpdated"] as Number?)?.toLong() ?: 0L
            )
            repo.setPrice(e)
        }

        // Stock movements
        fs.collection("$root/stock_movements").get().await().documents.mapNotNull { it.data }.forEach {
            val e = StockMovementEntity(
                id = it["id"] as String,
                itemId = it["itemId"] as String,
                unitId = it["unitId"] as String,
                qty = (it["qty"] as Number).toDouble(),
                note = it["note"] as String?,
                timestamp = (it["timestamp"] as Number?)?.toLong() ?: System.currentTimeMillis()
            )
            repo.addMovement(e)
        }
    }
}