package com.example.stocksync.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.stocksync.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val items: List<ItemWithRelations> = emptyList(),
    val units: List<UnitEntity> = emptyList(),
    val isSyncing: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository.get(app)

    private val itemsFlow = repo.itemsWithRelations()
    private val unitsFlow = repo.allUnits()

    val state: StateFlow<UiState> =
        combine(itemsFlow, unitsFlow) { items, units -> UiState(items = items, units = units) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    init { viewModelScope.launch { repo.seedDefaultUnits() } }

    fun addItem(name: String, sku: String){
        viewModelScope.launch { repo.addOrUpdateItem(ItemEntity(name = name, sku = sku)) }
    }
    fun deleteItem(id: String){
        viewModelScope.launch { repo.softDeleteItem(id) }
    }
    fun setPrice(itemId: String, unitId: String, price: Long){
        viewModelScope.launch { repo.setPrice(PriceEntity(itemId = itemId, unitId = unitId, price = price)) }
    }
    fun addMovement(itemId: String, unitId: String, qty: Double, note: String?){
        viewModelScope.launch { repo.addMovement(StockMovementEntity(itemId = itemId, unitId = unitId, qty = qty, note = note)) }
    }
}