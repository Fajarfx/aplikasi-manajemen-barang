package com.example.stocksync.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.stocksync.data.FirestoreSync
import com.example.stocksync.data.Repository

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val repo = Repository.get(applicationContext)
        val fs = FirestoreSync()
        val pending = repo.pending()
        return try {
            if (pending.isNotEmpty()) {
                fs.pushAll(pending)
                pending.forEach { repo.ackPending(it.id) }
            }
            fs.pullAll(repo)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}