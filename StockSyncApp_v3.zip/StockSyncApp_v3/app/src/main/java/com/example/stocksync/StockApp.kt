package com.example.stocksync

import android.app.Application
import androidx.work.*
import com.example.stocksync.work.SyncWorker
import com.google.firebase.auth.FirebaseAuth
import java.util.concurrent.TimeUnit

class StockApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // Anonymous auth: ensure per-user namespace
        if (FirebaseAuth.getInstance().currentUser == null) {
            FirebaseAuth.getInstance().signInAnonymously()
        }

        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "periodic_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}