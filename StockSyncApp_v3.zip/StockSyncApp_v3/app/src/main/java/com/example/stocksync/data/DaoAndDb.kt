package com.example.stocksync.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UnitDao {
    @Query("SELECT * FROM units ORDER BY name")
    fun all(): Flow<List<UnitEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vararg units: UnitEntity)
}

@Dao
interface ItemDao {
    @Transaction
    @Query("SELECT * FROM items WHERE deleted = 0 ORDER BY name")
    fun allWithRelations(): Flow<List<ItemWithRelations>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vararg items: ItemEntity)
    @Query("UPDATE items SET deleted = 1, lastUpdated = :ts WHERE id = :id")
    suspend fun softDelete(id: String, ts: Long)
}

@Dao
interface PriceDao {
    @Query("SELECT * FROM prices WHERE itemId = :itemId ORDER BY lastUpdated DESC")
    fun forItem(itemId: String): Flow<List<PriceEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vararg prices: PriceEntity)
}

@Dao
interface StockMovementDao {
    @Query("SELECT * FROM stock_movements WHERE itemId = :itemId ORDER BY timestamp DESC")
    fun forItem(itemId: String): Flow<List<StockMovementEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(vararg m: StockMovementEntity)
}

@Dao
interface PendingChangeDao {
    @Query("SELECT * FROM pending_changes ORDER BY lastUpdated ASC")
    suspend fun all(): List<PendingChangeEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vararg c: PendingChangeEntity)
    @Query("DELETE FROM pending_changes WHERE id = :id")
    suspend fun delete(id: String)
    @Query("DELETE FROM pending_changes")
    suspend fun clear()
}

@Database(
    entities = [UnitEntity::class, ItemEntity::class, PriceEntity::class, StockMovementEntity::class, PendingChangeEntity::class],
    version = 1
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun unitDao(): UnitDao
    abstract fun itemDao(): ItemDao
    abstract fun priceDao(): PriceDao
    abstract fun stockDao(): StockMovementDao
    abstract fun pendingDao(): PendingChangeDao
    companion object { const val NAME = "stocksync.db" }
}