package com.example.stocksync.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.stocksync.data.*
import com.example.stocksync.viewmodel.MainViewModel

@Composable
fun HomeScreen(nav: NavController, vm: MainViewModel){
    val state by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically){
            Text("Daftar Barang", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { nav.navigate("units") }) { Icon(Icons.Default.Settings, contentDescription = "Units") }
        }
        Spacer(Modifier.height(8.dp))
        if(state.items.isEmpty()){
            Text("Belum ada barang. Tekan tombol + untuk menambah.")
        } else {
            LazyColumn {
                items(state.items) { iw ->
                    ElevatedCard(
                        onClick = { nav.navigate("detail/${iw.item.id}") },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    ){
                        Column(Modifier.padding(12.dp)) {
                            Text(iw.item.name, style = MaterialTheme.typography.titleMedium)
                            Text("SKU: ${iw.item.sku}")
                            val pricePcs = iw.prices.firstOrNull { it.unitId == "pcs" }?.price
                            Text("Harga pcs: " + (pricePcs?.toString() ?: "-"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddItemScreen(onDone: ()->Unit, vm: MainViewModel){
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("Tambah Barang", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama barang") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU unik") }, modifier = Modifier.fillMaxWidth())
        }
        Button(onClick = {
            if(name.isNotBlank() && sku.isNotBlank()){
                vm.addItem(name, sku)
                onDone()
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Simpan")
        }
    }
}

@Composable
fun ItemDetailScreen(itemId: String, nav: NavController, vm: MainViewModel){
    val state by vm.state.collectAsState()
    val iw = state.items.firstOrNull { it.item.id == itemId } ?: return
    var showPriceDialog by remember { mutableStateOf(false) }
    var showMoveDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(iw.item.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("SKU: ${iw.item.sku}")
        Spacer(Modifier.height(16.dp))

        Text("Harga per unit", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if(iw.prices.isEmpty()) {
            Text("Belum ada harga. Tambahkan sekarang.")
        } else {
            iw.prices.forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Unit: ${p.unitId}")
                    Text("Rp ${p.price}")
                }
                Spacer(Modifier.height(4.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { showPriceDialog = true }) { Text("Tambah / Ubah Harga") }

        Spacer(Modifier.height(16.dp))
        Text("Pergerakan stok", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if(iw.movements.isEmpty()) Text("Belum ada pergerakan.")
        else LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
            items(iw.movements) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${if (m.qty>=0) "IN" else "OUT"} ${m.qty} ${m.unitId}")
                    Text(m.note ?: "")
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { showMoveDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Catat Pergerakan") }

        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { vm.deleteItem(iw.item.id); nav.popBackStack() }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
            Text("Hapus Barang")
        }
    }

    if(showPriceDialog){
        PriceDialog(units = state.units, onDismiss = { showPriceDialog = false }) { unitId, price ->
            vm.setPrice(iw.item.id, unitId, price); showPriceDialog = false
        }
    }
    if(showMoveDialog){
        MovementDialog(units = state.units, onDismiss = { showMoveDialog = false }) { unitId, qty, note ->
            vm.addMovement(iw.item.id, unitId, qty, note); showMoveDialog = false
        }
    }
}

@Composable
fun UnitsScreen(vm: MainViewModel){
    val state by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Unit & Konversi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        state.units.forEach { u ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(u.name)
                Text("= ${u.toBaseMultiplier} pcs")
            }
            Spacer(Modifier.height(6.dp))
        }
        Text("Untuk menambah/mengubah unit saat ini lakukan di seedDefaultUnits() (bisa dibuat UI jika diperlukan).")
    }
}

@Composable
fun PriceDialog(units: List<UnitEntity>, onDismiss:()->Unit, onSave:(String, Long)->Unit){
    var unitId by remember { mutableStateOf(units.firstOrNull()?.id ?: "pcs") }
    var priceText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                priceText.toLongOrNull()?.let { onSave(unitId, it) }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Harga per Unit") },
        text = {
            Column {
                ExposedDropDownUnit(units = units, selected = unitId, onSelected = { unitId = it })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(priceText, { priceText = it }, label = { Text("Harga") })
            }
        }
    )
}

@Composable
fun MovementDialog(units: List<UnitEntity>, onDismiss:()->Unit, onSave:(String, Double, String?)->Unit){
    var unitId by remember { mutableStateOf(units.firstOrNull()?.id ?: "pcs") }
    var qtyText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                qtyText.toDoubleOrNull()?.let { onSave(unitId, it, note.ifBlank { null }) }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        title = { Text("Catat Pergerakan") },
        text = {
            Column {
                ExposedDropDownUnit(units = units, selected = unitId, onSelected = { unitId = it })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(qtyText, { qtyText = it }, label = { Text("Qty (+ masuk / - keluar)") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") })
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExposedDropDownUnit(units: List<UnitEntity>, selected: String, onSelected:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text("Unit") },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            units.forEach { u ->
                DropdownMenuItem(
                    text = { Text(u.name) },
                    onClick = { onSelected(u.id); expanded = false }
                )
            }
        }
    }
}