package com.example.stocksync.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF2563EB) // blue-600
val Secondary = Color(0xFF059669) // emerald-600
val Accent = Color(0xFFF59E0B) // amber-500