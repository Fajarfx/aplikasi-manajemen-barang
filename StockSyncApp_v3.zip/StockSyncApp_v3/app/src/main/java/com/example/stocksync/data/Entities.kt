package com.example.stocksync.data

import androidx.room.*
import java.util.UUID

@Entity(tableName = "units")
data class UnitEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,        // e.g., "pcs", "bks", "pak"
    val toBaseMultiplier: Double // 1 unit = x pcs
)

@Entity(tableName = "items", indices = [Index(value = ["sku"], unique = true)])
data class ItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val sku: String,
    val baseUnitId: String = "pcs",
    val lastUpdated: Long = System.currentTimeMillis(),
    val deleted: Boolean = false
)

@Entity(
    tableName = "prices",
    foreignKeys = [
        ForeignKey(entity = ItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = UnitEntity::class, parentColumns = ["id"], childColumns = ["unitId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("itemId"), Index("unitId")]
)
data class PriceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val itemId: String,
    val unitId: String,
    val price: Long,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_movements",
    foreignKeys = [
        ForeignKey(entity = ItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = UnitEntity::class, parentColumns = ["id"], childColumns = ["unitId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("itemId"), Index("unitId")]
)
data class StockMovementEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val itemId: String,
    val unitId: String,
    val qty: Double, // +in / -out (in 'unitId')
    val note: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "pending_changes")
data class PendingChangeEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val tableName: String, // "items" | "prices" | "stock_movements" | "units"
    val payloadJson: String,
    val op: String, // "upsert" | "delete"
    val lastUpdated: Long = System.currentTimeMillis()
)

data class ItemWithRelations(
    @Embedded val item: ItemEntity,
    @Relation(parentColumn = "id", entityColumn = "itemId")
    val prices: List<PriceEntity>,
    @Relation(parentColumn = "id", entityColumn = "itemId")
    val movements: List<StockMovementEntity>
)