package com.example.stocksync

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.stocksync.ui.theme.StockTheme
import com.example.stocksync.viewmodel.MainViewModel
import com.example.stocksync.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StockTheme {
                val nav = rememberNavController()
                val vm: MainViewModel = viewModel()

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("StockSync") },
                            actions = { Icon(imageVector = Icons.Default.Sync, contentDescription = null) }
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(onClick = { nav.navigate("addItem") }) {
                            Icon(Icons.Default.Add, contentDescription = "Tambah")
                        }
                    }
                ) { padding ->
                    NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                        composable("home") { HomeScreen(nav, vm) }
                        composable("addItem") { AddItemScreen(onDone = { nav.popBackStack() }, vm) }
                        composable("detail/{itemId}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("itemId") ?: return@composable
                            ItemDetailScreen(itemId = id, nav = nav, vm = vm)
                        }
                        composable("units") { UnitsScreen(vm = vm) }
                    }
                }
            }
        }
    }
}